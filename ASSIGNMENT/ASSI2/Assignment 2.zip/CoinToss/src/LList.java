/**
 * A linked implemention of the ADT list. This uses a single link (no tail is to be used).
 * 
 * @author your name here
 */

public class LList<T> implements ListInterface<T> {

	public LList() {
		initializeDataFields();
	} // end default constructor

	// Initializes the class's data fields to indicate an empty list.
	private void initializeDataFields() {
		// TASK - IMPLEMENT THIS
	} // end initializeDataFields

	@Override
	public void add(T newEntry) {
		// TODO Auto-generated method stub

	}

	@Override
	public void add(int newPosition, T newEntry) {
		// TODO Auto-generated method stub

	}

	@Override
	public T remove(int givenPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

	@Override
	public T replace(int givenPosition, T newEntry) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T getEntry(int givenPosition) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(T anEntry) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

} // end LList
